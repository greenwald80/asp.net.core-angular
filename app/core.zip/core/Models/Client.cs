namespace app{
    public class Client{
        public string Name {get; set;}
        public int Age {get; set;}
    }
}