using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;

//namespace core.Controllers;
using app;

[ApiController]
[Route("api/client")]
public class ClientsController : ControllerBase
{
  [HttpGet]
  [Route("getall")]
  public IEnumerable<Client> GetAll()
  {
    return new[]
    {
           new Client{Name="A", Age=1},
           new Client{Name="B", Age=2},
           new Client{Name="C", Age=3}
        };
  }
}

