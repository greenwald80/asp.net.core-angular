using Microsoft.AspNetCore.Mvc;


//namespace core.Controllers;

// [ApiController]
// [Route("[controller]")]
public class HomeController : Controller
{
  [HttpGet]
  public ActionResult Index()
  {
    return View();
  }
}
